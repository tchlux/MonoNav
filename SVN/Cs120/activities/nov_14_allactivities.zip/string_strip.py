def strip_non_alpha(text):
    length = len(text)
    string = ""
    for i in range(0,length):
        character = text[i]
        char = ord(character)
        if 97 <= char <= 122 or 65 <= char <= 90:
            string = string + character
    return string

print(strip_non_alpha(input("Characters & Numbers: ")))


#h3e4l0p4
