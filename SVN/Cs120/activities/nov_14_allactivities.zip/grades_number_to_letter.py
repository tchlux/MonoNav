def tell_me_the_lettah():
    n = input("What's the n?????? ")
    print(n)
    if 100 >= n >= 90:
        print(" It's an A mudda")
    if 90 > n >= 80:
        print(" It's a B :O ")
    if 80 > n >= 70:
        print(" It's a C, bt dubs you're a loooooser")
    if 70 > n >= 60:
        print(" D, gooo home poo face")
    if 60 > n:
        print(" Well I don't know how to put this to you...")
        print("   you have recieved a letter grade that qualifies you for")
        print(" immediate psychiatric help.  Don't take it personally, ")
        print("  but a great person to go and see is our wonderful Dr. Bouchard")
        print(" call him at his home phone, 540 - you - fail")
        print(' adios muchachos')

tell_me_the_lettah()
