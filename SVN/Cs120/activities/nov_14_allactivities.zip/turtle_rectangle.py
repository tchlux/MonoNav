
import turtle
fresco = turtle.Turtle()

length = 100
width = 50

# this sends the turtle forward for the distance specified for length and then   turns the turtle 90 degrees to the right
# pre: real, positive, preferrably integer number
# post: turtle moves that distance forward
def rectangle_length(length):
    fresco.forward(length)
    fresco.right(90)

# this sends the turtle forward for the distance specified for width and then    turns the turtle 90 degrees to the right
# pre: real, positive, preferrably integer number
# post: turtle moves that distance forward
def rectangle_width(width):
    fresco.forward(width)
    fresco.right(90)

rectangle_length(length)
rectangle_width(width)
rectangle_length(length)
rectangle_width(width)

turtle.mainloop()


