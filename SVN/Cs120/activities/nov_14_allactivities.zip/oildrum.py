pi = 3.14158
drum_radius = 11.25
drum_height = 33.5
cubic_inches_in_a_gallon = 231
drum_base_area = pi * drum_radius * drum_radius
drum_volume_in_cubic_inches = drum_base_area * drum_height
drum_volume_in_gallons = drum_volume_in_cubic_inches / cubic_inches_in_a_gallon



print("If the radius of the oil drum is 11.25 inches,")
print(" and the height of the drum is 33.5 inches")
print("then that means the volume of the drum is",(pi * drum_radius ** 2) * drum_height)
print(" square inches.  Also denoted as",((pi * drum_radius ** 2) * drum_height) / 231,"in gallons")


# now some test data using functions to go beneath

