def is_alphabetic(character):
    char = ord(character)
    boolean = bool("True")
    if 97 <= char <= 122 or 65 <= char <= 90:
        boolean = bool("True")
    else:
        boolean = bool("False")
    return boolean

print(is_alphabetic(input("Single character: ")))
