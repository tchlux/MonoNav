import math
#  !!!

def value_of_pi(n):
    pi = 0
    variable = -1
    for i in range (1, n, 2):
        variable = variable + 1
        pi = (pi + ((-1) ** (variable)) / i)
        #print(" values", pi * 4)
    pi = pi * 4
    return pi

# the higher the number, the more accurate the estimate is
print('The approximate value of pi is', value_of_pi(10 ** 6))
