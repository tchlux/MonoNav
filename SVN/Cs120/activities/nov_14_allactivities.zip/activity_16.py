number = '10101010'

def binary_to_decimal(number):
    length = len(number)
    print('length', length)
    for i in range(length+1)
