import turtle
fresco = turtle.Turtle()

def make_star (length):
    fresco.forward(length)
    fresco.right(144)

length = 144

make_star(length)
make_star(length)
make_star(length)
make_star(length)
make_star(length)


turtle.mainloop()
