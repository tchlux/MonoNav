# def square(a_number):
#         a_number_squared = a_number * a_number
#         return a_number_squared

# def power(base , exponent):
#     the_power = base ** exponent
#     return the_power

# print(square(2))
# print(square(5))
# print(power(2, 3))



##### EMACS TEST CODE RUNNER #####


import math
spam = 0
for i in range(int(math.sqrt(5))):
    spam = spam + 1
print(spam)
