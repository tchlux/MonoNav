print("I am",365.0*19*24*60*60,"seconds old!")
