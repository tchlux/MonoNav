
# a. no
# b. yes
# c. yes
# d. yes
# e. yes
# f. no

import math
import decimal

def decimal_print():
    print(decimal.Decimal(.1))
    print(.1, "these should be the same")

def decimal_print_ten():
    point_one = 0
    for i in range (10):
        point_one += .1
    print(point_one)
    print("answer should be", 1)
    print(" they are not the same because binary is a bad rounder!")

def result_of_comparison_of_point_three_and_point_one_plus_point_two():
    print(0.3 == 0.1 + 0.2)
    print(' it should be written = not ==, the latter is a bool operation')

def round_the_number_to_two_decimal_places():
    print(round(2.675,2))
    print(" this rounded 2.675")
    print(' this is incorrect because the round function chops')
    print(' 0.25 rounded', round(0.25,1))

def vigenere_encipher(text, key):
    
    length_of_text = len(text)
    length_of_key = len(key)
    count = math.ceil(length_of_text / length_of_key)
    number_of_runs = 0
    for i in range(count):
        number_of_runs += 1
        location_in_text = number_of_runs * i

    pass

def key_to_number_rotated(letter, key):
    pass

def rotate_specified_value(letter, number):
    pass

#decimal_print()
#decimal_print_ten()
#result_of_comparison_of_point_three_and_point_one_plus_point_two()
#round_the_number_to_two_decimal_places()

vigenere_encipher(input("text to be encrypted!LS()#kd039j:  "), input('keys mudda: '))
