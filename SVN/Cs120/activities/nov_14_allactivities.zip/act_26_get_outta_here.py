dictionary = {"spam": 1, "eggs": 2, "ham": 3}
value = 2

def gimme_a_dictionary_and_value(dictionary, value):
    dictionary_length = len(dictionary)
    list_of_keys = dictionary.keys()
    i = 0
    while len(dictionary) == dictionary_length:
        if list_of_keys[i] == value:
            del dictionary[key]
        i += 1
    print('done')
    print('dictionary', dictionary)


gimme_a_dictionary_and_value(dictionary, value)
