

def ask_and_add_numbers ():
    number_of_numbers = int(input("Number of numbers? "))
    number = 0
    for i in range (1,number_of_numbers+1):
        new_number = int(input("Positive integer?"))
        if new_number >= number:
            number = new_number
        elif new_number < number:
            print(' hahaha that was less than the max!')
        else:
            print(" hush martyr paleologists")
    return number

#print("The largest number entered was..", ask_and_add_numbers(),"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")





def print_average_of_numbers():
    lots_of_numbers = input("A bunch uh numbas wit commas an spaseson sekun thawt, no kammus ")
    list_of_the_last_thing = lots_of_numbers.split(" ")
    print(list_of_the_last_thing)
    total = 0
    for item in list_of_the_last_thing:
        int_item = int(item)
        total += int_item
    length = len(list_of_the_last_thing)
    average = total / length
    return average

print("average = ",print_average_of_numbers())
