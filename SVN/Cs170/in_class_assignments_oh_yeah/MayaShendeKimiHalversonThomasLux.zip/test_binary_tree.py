from binary_search_tree import BinaryTree

tree_1 = BinaryTree()
tree_2 = BinaryTree()
tree_3 = BinaryTree()

tree_1.insert(8)
tree_1.insert(5)
tree_1.insert(3)
tree_1.insert(1)
tree_1.insert(4)
tree_1.insert(6)
tree_1.insert(11)
tree_1.insert(9)
tree_1.insert(12)
tree_1.insert(10)

tree_2.insert(10)
tree_2.insert(9)
tree_2.insert(6)
tree_2.insert(1)
tree_2.insert(5)
tree_2.insert(8)
tree_2.insert(3)
tree_2.insert(4)
tree_2.insert(11)
tree_2.insert(12)


for i in range(10):
    tree_3.insert(i)

print(tree_1.search(7))
print(tree_2.search(7))
print(tree_3.search(7))
