class Stack:

    #push - Adds the new_object to the top of the stack
    #Pre:   new_object can have any type representable within python.
    #       The internal data structure is able to operate as a stack
    #Post:  Puts new_object on the top of the internal data structure
    def push(self, new_object):
        pass

    #pop  - Removes the top element of the stack, and returns it
    #Pre:   The internal data structure is able to operate as a stack
    #Post:  Removes the top element of the internal data structure,
    #       and returns it.
    def pop(self):
        pass

    #peek - Returns a copy of the data on the top of the stack
    #Pre:   The internal data structure is able to operate as a stack
    #Post:  Returns a copy of the data stored as the top of the
    #       internal data structure.
    def peek(self):
        pass

    #is_empty - Does the stack contain anything?
    #Pre:       The internal data structure is able to operate as a
    #           stack.
    #Post:      Returns False if there are items within the stack,
    #           True otherwise.
    def is_empty(self):
        pass
