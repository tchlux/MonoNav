
#Class:   This is the class for the word trie
#Mainloop:No
class Trie:
    #Class:   This is the private class for a node in the trie
    class _Node:
        #Method:Constructor, creates all attributes
        #Pre:   parent node (_Node), letter (String), and next level
        #       (List) can be provided
        #Att's: created here
        #Post:  The _Node is essentially inserted into the trie
        def __init__(self, parent, letter, next_level=[]):
            self.parent = parent
            self.letter = letter
            self.terminator = terminator
            self.next_level = next_level

        #Method:This will return the string of the word in reverse order
        #Pre:   The string method is called on this node
        #Att's: self.parent (type=_Node)
        #       self.letter (type=String)
        #Post:  The string from the current node and up to root is
        #       returned 
        def __str__(self):
            if self.parent.letter == None:
                return str(self.letter)
            else:
                return str(self.letter)+str(self.parent)

    #Class:   This class iterates through words in the trie
    class _Iterator:
        #Method:Constructor
        #Pre:   trie is given (Trie)
        #Att's: created here
        #Post:  the trie is iterated through
        def __init__(self, trie):
            self.node = trie.root
            self.level_path = []

        #Method:This method cycles through the words in the trie
        #Pre:   called by iterator
        #Att's: todo
        #Post:  the next word in the trie is given
        def __next__(self):
            pass

    #Method:Constructor for Trie
    #Pre:   Trie is created
    #Att's: self.root =>> _Node
    #Post:  the trie is ready to be added to
    def __init__(self):
        self.root = self._Node(None,None)

    #Method:This method adds all necessary nodes and values for the
    #       given word to the self
    #Pre:   Word is given as a string
    #Att's: todo
    #Post:  The word is added to the trie
    def add_word(self, word):
        pass

    #Method:This method returns a bool for whether or not a given word
    #       exists in self
    #Pre:   A word is given as a string
    #Att's: todo
    #Post:  A boolean is returned for if the word does exist
    def word_exists(self, word):
        pass
