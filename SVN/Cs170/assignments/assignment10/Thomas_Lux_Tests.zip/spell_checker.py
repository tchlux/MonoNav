import trie

#Search Term:  todo


#Class:   This is the spell checker class
#Runtime: < 1 second
#Mainloop:Yes, for interactive mode
class SpellChecker:
    #Method:Consructor, creates all necessary attributes for the spch class
    #Pre:   The word file can be given as a command line argument or
    #       regular argument
    #Att's: self.dictionary (type=Trie class)
    #Post:  The spell checker is initialized
    def __init__(self, word_file=None):
        self.dictionary = trie.Trie()

    #Method:This method imports the dictionary and returns it as a
    #       list of words
    #Pre:   A filename is given as a string or None
    #Att's: None required
    #Post:  A list of each line in the specified file are returned, an
    #       exception is raised if no filename was given
    def _import_dict(self, filename):
        #This is a check to see if the filename was given on
        #initialization or as a system argument, if neither raises
        #exception
        try:
            filename = sys.argv[1]
            print("I see you at the command line.")
        except IndexError:
            if filename == None:
                raise Exception("There needs to be file name given either upon initialization or as a system argument.")
        #This is what opens the file
        with open(filename) as dictionary:
            line_list = dictionary.readlines()
            dictionary.close()
        return line_list

    #Method:This method creates the dictionary trie given the list of lines
    #Pre:   Line list is given as a list of strings (one word per string)
    #Att's: todo
    #Post:  self.dictionary is filled with words from the line_list
    def _create_dictionary(self, line_list):
        pass

    #Method:This method will add a word to the dictionary trie
    #Pre:   The word is given as a string
    #Att's: self.dictionary (type=Trie class)
    #Post:  The word is added to the trie
    def add_word(self, word):
        self.dictionary.add_word(word)

    #Method:This method will return true or false for if a word exists
    #       in self.dictionary
    #Pre:   a word is given as a string
    #Att's: self.dictionary (type=Trie class)
    #Post:  Boolean response for if the word exists in the trie
    def find_word(self, word):
        return self.dictionary.word_exists(word)

    #Method:This method will provied similarly spelled words given a word
    #Pre:   A word is given as a string
    #Att's: todo
    #Post:  A list of other words possible is given
    def provide_correction(self, word):
        pass

    #Method:This method will run the terminal mainloop
    #Pre:   None
    #Att's: todo
    #Post:  The interactive spell checker is run
    def mainloop(self):
        pass

if __name__ == "__main__":
    spch = SpellChecker("words.txt")
    spch.mainloop()
