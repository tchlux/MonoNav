#This will test the complex numbers addition

a = ComplexNumber(1, 1)
b = ComplexNumber(1, 1)
#c will be the resultant complex number of adding the two above
c = a+b
#This will print the a and b of complex number ,c
print("a= "+str(c.a), "b= "+str(c.b))

#This should add together the two complex numbers above and return a
#new complex number with the value of a= 2 b= 2



#This will test the complex numbers multiplication

a = ComplexNumber(2, 2)
b = ComplexNumber(1, 1)
#c will be the resultant complex number of multiplying the two above
c = a*b
#This will print the a and b of complex number ,c
print("a= "+str(c.a), "b= "+str(c.b))

#This should multiply the two complex numbers a and b and return a new
#complex number with the value of a= 0 b= 4



#This will test the complex number's magnitude

a = ComplexNumber(3, 4)
#This will print the magnitude of a
print(str(a.magnitude()))

#This should print the value 5, the magnitude of complex number a
