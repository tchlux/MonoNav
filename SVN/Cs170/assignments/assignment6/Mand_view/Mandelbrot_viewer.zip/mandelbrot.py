import ppm
import turtle
import math
import sys
import time
import os

WIDTH = 80
HEIGHT = WIDTH
COLOR_FACTOR = 255
#Maximum color factor of 3.8*255
#for a, more positive moves picture left
#for b, more positive moves picture up

A = .2788
B = -.61
SIZE = .005

#                self.ppm.draw_pixel((x,y),(round((color/COLOR_FACTOR)*255), 10, 40))#Deep blue to red


#This class will hold all of the necessary equations for a mandelbrot image.
class Mandelbrot:
    #Constructor, this method will initialize all attributes and start
    #the process of calculating a mandelbrot image
    #Pre:   The mandelbrot class is created
    #Post:  The attributes are created and the process begins
    def __init__(self, parent, a=A, b=B, size=SIZE, dimensions=WIDTH, rl=0, rm=COLOR_FACTOR//2, rh=COLOR_FACTOR, gl=5, gm=10, gh=15, bl=30, bm=40, bh=50, depth=COLOR_FACTOR):
        self.parent = parent
        self.status = 0
        self.depth = depth
        self.rl = rl
        self.rm = rm
        self.rh = rh
        self.gl = gl
        self.gm = gm
        self.gh = gh
        self.bl = bl
        self.bm = bm
        self.bh = bh
        self.dim = dimensions
        self.time = time.time()
        # lst = sys.argv
        # self.a, self.b = self.convert_to_pixel_coord(float(lst[1]), float(lst[2]))
        # self.hsize = float(lst[3])/2
        self.ppm = ppm.PPM(width=self.dim, height=self.dim)
        self.a, self.b, self.hsize = a, b, float(size/2)

    
    def run(self):
        self.mandelbrot()

    def begin(self):
        self.mandelbrot()

    #This method converts complex coordinates to pixel coordinates
    #Pre:   The a and b values of the complex numer
    #Post:  Two numbers that are the corresponding pixel coordinates
    def convert_to_pixel_coord(self, x, y):
        pixx = self.dim/2 + ((x-2)/4)*self.dim
        pixy = self.dim/2 + ((y-2)/4)*self.dim
        return pixx, pixy

    def interpolate(self, c1, c2, i):
        return (int((1-i)*c1[0] + i*c2[0]), int((1-i)*c1[1] + i*c2[1]), int((1-i)*c1[2] + i*c2[2]))

    #This method will create the mandelbrot image
    #Pre:   The method is called
    #Post:  The Mandelbrot image is made and written to a file
    def mandelbrot(self):
        min_x = self.a - self.hsize
        min_y = self.b - self.hsize
        x_diff = (self.a+self.hsize) - min_x
        y_diff = (self.b+self.hsize) - min_y
        #These two equations are used to convert pixels coordinates to complex coordinates
        x_complex = lambda x: x/self.dim * (x_diff) + min_x
        y_complex = lambda y: y/self.dim * (y_diff) + min_y
        #This loop goes through and draws the Mandelbrot by pixels
        for y in range(self.dim):
            for x in range(self.dim):
#recursive      value = ComplexNumber(x_complex(x), y_complex(y))
#recursive      self.initial = value
#               cnum = ComplexNumber(x_complex(x), y_complex(y))
                cnum = complex(x_complex(x), y_complex(y))
                init = cnum
                depth = self.depth
                for i in range(self.depth):
                    cnum = cnum*cnum + init
#                    if cnum.magnitude() > 2:
                    if abs(cnum) > 2:
                        depth = i
                        break

#recursive      i = self.calculate_pixel(value, 0)
#recursive      self.ppm.draw_pixel((x,y),(round((i/COLOR_FACTOR)*255), 10, 40))#Deep blue to red
                if depth <= self.depth//2:
                    c = depth/(self.depth//2)
                    self.ppm.draw_pixel((x,y),self.interpolate((self.rl, self.gl, self.bl),(self.rm, self.gm, self.bm),c))
                else:
                    c = (depth-self.depth//2)/self.depth
                    self.ppm.draw_pixel((x,y),self.interpolate((self.rm, self.gm, self.bm),(self.rh, self.gh, self.bh),c))


            self.parent.statbar["value"] = y
            self.parent.root.update_idletasks()
        self.ppm.save_image("Mandelbrot.ppm")
        self.parent.statbar["value"] = 0
        self.parent.statbar.grid_forget()
        self.parent.root.informme["text"] = self.parent.inform



    #This method will recursively calculate the color for the complex number
    #provided through testing of recursion depth
    #Pre:   A complex number, and a current depth
    #Post:  The depth associated with that pixel
    def calculate_pixel(self, cnum, depth):
        cnum = cnum*cnum + self.initial
        if depth == self.depth or abs(cnum.magnitude()) > 2:
            return depth
        else:
            return self.calculate_pixel(cnum, depth+1)




#This class will represent a complex numer
class ComplexNumber:
    #Constructor, this will create a complex number with corresponding
    #attributes
    #Pre:   The a and b values are given
    #Post:  The complex number's attributes are created and ready to be used
    def __init__(self, a, b):
        self.a = a
        self.b = b

    #This method will return the magnitude of a complex number
    #Pre:   None, the method is called
    #Post:  The magnitude of the complex number is returned. (distance
    #from origin)
    def magnitude(self):
        return (self.a**2 + self.b**2)**(1/2)

    #This method will add the current complex number to another
    #complex number
    #Pre:   Another complex number is being added
    #Post:  The addition of the two is returned
    def __add__(self, cnum):
        return ComplexNumber(self.a+cnum.a, self.b+cnum.b)

    #This method will multiply the current complex number with another
    #Pre:   Another complex number is provided
    #Post:  The product of the complex numbers is returned
    def __mul__(self, cnum):
        return ComplexNumber(self.a*cnum.a - self.b*cnum.b, self.a*cnum.b + cnum.a*self.b)


if __name__ == "__main__":
    a = Mandelbrot()
    a.begin()


#Explore around this location!
# A = .28
# B = -.61
# SIZE = .2

# limit of program in the center of star
# A = .3663629834227642
# B = -0.5915337732614456
# SIZE = 1.7763568394002505 * 10 **(-15)
#Attempted zoom reached recursive limits for our program (can't see far enough)
# A = -.1025
# B = .894
# SIZE = .04
# A = -1.25516
# B = .38208
# SIZE = .0001
#Mandelbrot6
# A = -1.2558
# B = .3813
# SIZE = .007
#Mandelbrot5
# A = -.108855
# B = .892125
# SIZE = .0001
#Mandelbrot100
# A = .2720
# B = .4805
# SIZE = .0015
