# as all of the comments state

#the board will be initialized, with it all of the pieces will be added

#the only thing the user will have to enter is a piece reference and a loctaion of where to go

#the location will be tested and confirmed before the piece is moved

#the board will be re-printed after each move

#all pieces will inherit from a very generic class for a piece

#the expected outputs are the graphs below but on the command line

#the board will have options for turning on an AI (inherent second player)
# and a second player that offers a second prompt, the second player's pieces will have
# different names so the moves do not get confused
