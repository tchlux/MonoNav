#all variables
class Variables():

#this is where all the game variables are stored
    def __init__(self):
        self.level = 1
        self.frame_rate = 30

        # self.bcolor = "black"
        self.bradius = 10 *(1/self.level)
        self.bspeed = 4 *self.level**(1/2)
        self.bimage = "ball.gif"

        # self.pcolor = "black"
        self.ptopleft = (-50,-250)
        self.pwidth = 100
        self.pheight = 15
        self.pimage = "paddle.gif"
        self.pspeed = 3 *self.level


#w is a weak brick
        self.wstrength = int(1 *self.level)
        self.wwidth = 80 *(1/self.level)
        self.wheight = 32 
        self.wimage = "brick1.gif"
#s is a strong brick
        self.sstrength = int(2 *self.level)
        self.swidth = 100 *(1/self.level)
        self.sheight = 40
        self.simage = "brick2.gif"

#world is for the window
        self.worldh = 450
        self.worldw = 650
        self.worldbg = "cyan"

        # self.shapes = []
        # self.shapes.append(self.bimage)
        # self.shapes.append(self.pimage)
        # self.shapes.append(self.wimage)
        # self.shapes.append(self.simage)
