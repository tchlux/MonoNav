import stack_and_queue

#Class:    This class is for timing the execution of methods in our
#          stacks and queues
#Runtime:  This will just be based on the execution of the timers
#Mainloop: No
class Timer:
    #Method: This method initializes the timer
    #Pre:    None
    #Att's:  They are initialized
    #Post:   The timing process begins
    def __init__(self):
        pass

    #Method: This method will time the stack and queues
    #Pre:    Called
    #Att's:  self.time_queue (type=Method)
    #        self.time_stack (type=Stack)
    #Post:   The two operations are timed and printed
    def time_stack_and_que(self):
        pass

    #Method: This method will execute an operation on the queue
    #Pre:    The method is called
    #Att's:  self.queue (type=Queue class instance)
    #Post:   The operation is executed on the queue
    def time_queue(self):
        pass

    #Method: This method will execute an operation on the stack
    #Pre:    The method is called
    #Att's:  self.stack (type=Stack class instance)
    #Post:   The operation is executed on the stack
    def time_stack(self):
        pass
