import list_search as searcher
import random



def search_list(search_term, lst):
    result = searcher.binary_search(lst, search_term)
    print("Is the item in the list??? only we know!")
    print(lst)
    print(result)
    if result:
        print('we found it!')

lst = [i for i in range(100)]
search_term = 99#random.randint(-20,120)
print("this is how we do it:", search_term)
search_list(search_term, lst)
